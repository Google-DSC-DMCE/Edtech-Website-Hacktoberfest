<!DOCTYPE html>
<html lang="en">
<head>
  <title>NOTES</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="css/index.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body style="overflow-y: scroll;">
  <div class="bgimg" style="height: 810px;">
  <header>
       <nav class="navbar navbar-inverse">
            <div class="container-fluid">
            <div class="navbar-header">
      
        </div>
             <ul class="nav navbar-nav">
              <li><a href="index.php">Home</a></li>
              <li><a href="notes.php">Notes</a></li>
              <li><a href="experiment.php">Experiment</a></li>
              <li><a href="project.php">Project</a></li>
              <li><a href="mocktest.php">Mock Test</a></li>
      
             </ul>
        </div>
        </nav>
  </header>      
</div>
  
    <footer class="foot">
        <div class="contactus">
           <h4 style="text-align: center;"> Contact Us </h4>

            <p> For details study of every topic, kindly visit <a href="https://www.w3schools.com/">  w3schools  </a>    For uploading any other study Material or issues on the portal kindly send your feedback us. <br> Email: studypoint@gmail.com <br>  </p> 
  
        </div>

    </footer>

</body>
</html>
